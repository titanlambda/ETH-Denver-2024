import json
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.params import File
import uvicorn
import os
from zipfile import ZipFile
import tempfile
import datetime
import random
import requests
from pydantic import BaseModel
from pydantic import BaseModel
from typing import List
import uuid
import tempfile

import requests
import cv2
import numpy as np
from io import BytesIO

import requests
from PIL import Image
from io import BytesIO
import imagehash


app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

#get_risk_score_get_phosphor_NFT_risk_score
@app.get("/api/get_risk_score_get_phosphor_NFT_risk_score")
async def get_risk_score_get_phosphor_NFT_risk_score(nft_collection_id:str):
    url = "https://admin-api.phosphor.xyz/v1/collections/{0}".format(nft_collection_id)

    payload = {}
    headers = {
        'Phosphor-Api-Key': '10980424947d45ee8b6959b746a2a608',
        'Cookie': '__cf_bm=ZK5Ilm7mMEjEuUglXQrPBMFPW40_efZj8nZ1zcPaS1c-1709385941-1.0.1.1-AwnGJo.mnsSmbC2TqitG4iX9NQlGPoDYH9p6NMH7m_mSZzKi4wXiCEjqEnftFDep73bL_T_mlTXEKEpvsn08Zg'
    }

    response = requests.request("GET", url, headers=headers, data=payload)

    print(response.text)

    json_response = json.loads(response.text)
    image_url = json_response["image_url"]
    json_response["risk_score"] = analyze_image(image_url)
    return json_response


def fetch_image(image_url):
    response = requests.get(image_url)
    image = np.array(bytearray(response.content), dtype=np.uint8)
    image = cv2.imdecode(image, -1)
    return image

def fetch_image2(image_url):
    response = requests.get(image_url)
    image = Image.open(BytesIO(response.content))
    return image



def check_for_obscenity(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
    return laplacian_var < 100


def analyze_image(image_url):
    image = fetch_image(image_url)
    if check_for_obscenity(image):
        return "100"
    elif is_duplicate_of_nft(image_url):
        return "90"
    else:
        return "0"

def generate_image_hash(image):
    hash = imagehash.phash(image)
    return str(hash)


def is_duplicate_of_nft(image_url):
    duplicate_image_hash = "b9613cc38fc68d32"

    nft_match = False  # Placeholder result

    # Fetch the image
    image = fetch_image2(image_url)

    # Generate a perceptual hash of the image
    image_hash = generate_image_hash(image)
    if image_hash == duplicate_image_hash:
        nft_match = True

    if nft_match:
        print("The image is a duplicate of an NFT.")
    else:
        print("The image is not a duplicate of an NFT.")
    return nft_match


if __name__ == "__main__":
    host = os.getenv("HOST")
    port = 8080
    uvicorn.run(app, host=host, port=port)


    # # Duplicate NFT Check
    # image_url = "https://i.seadn.io/gae/8A-rNl0w3nJfyWMGo_0FyiVeQmoDdY3WwxUHzydL9Umx3uGZA9xlT_IU5qZc-Bxh19Pl3k9MlTHJ32MFunb2vcMtMuexUMcjqbJa?auto=format&dpr=1&w=1000"
    # is_duplicate = is_duplicate_of_nft(image_url)
    # print(is_duplicate)
    #
    # # Non Duplicate
    # image_url = "https://nftprodstorage.blob.core.windows.net/public/QmSdxwBWr19pGzZfDsS3PPkdBuVF1mfWAFnhVXAdN2CYbr/phosphor-collection-logo.png"
    # is_duplicate = is_duplicate_of_nft(image_url)
    # print(is_duplicate)
