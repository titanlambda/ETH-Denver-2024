import requests
import cv2
import numpy as np
from io import BytesIO

def fetch_image(image_url):
    response = requests.get(image_url)
    image = np.array(bytearray(response.content), dtype=np.uint8)
    image = cv2.imdecode(image, -1)  # '-1' to read the image as is (with alpha channel if present)
    return image

def is_image_blurred(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
    return laplacian_var < 100  # Threshold value, might need adjustment

def check_for_obscenity(image):
    # Placeholder for obscenity detection
    # In practice, you would call an external API or use a pre-trained model here
    # return call_to_obscenity_detection_api(image)
    return False  # Example placeholder return

def analyze_image(image_url):
    image = fetch_image(image_url)
    if is_image_blurred(image):
        return "100"
    elif check_for_obscenity(image):
        return "100"
    else:
        return "0"

if __name__ == "__main__":
    ## Clear BYAC Duplicate Fraud Image
    image_url = "https://i.seadn.io/gae/8A-rNl0w3nJfyWMGo_0FyiVeQmoDdY3WwxUHzydL9Umx3uGZA9xlT_IU5qZc-Bxh19Pl3k9MlTHJ32MFunb2vcMtMuexUMcjqbJa?auto=format&dpr=1&w=1000"
    result = analyze_image(image_url)
    print(result)

    ## Clear Image Authentic
    image_url = "https://nftprodstorage.blob.core.windows.net/public/QmSdxwBWr19pGzZfDsS3PPkdBuVF1mfWAFnhVXAdN2CYbr/phosphor-collection-logo.png"
    result = analyze_image(image_url)
    print(result)

    ## Clear NSFW Image
    image_url = "https://fiverr-res.cloudinary.com/images/t_main1,q_auto,f_auto,q_auto,f_auto/gigs2/326507393/original/84036e370689713abd30456b0bb68785f79e7eea/create-custom-nsfw-images-for-you.png"
    result = analyze_image(image_url)
    print(result)

    # Blurred Image
    image_url = "https://hugoarcier.com/test/wp-content/uploads/2014/07/amateur_still02.jpg"
    result = analyze_image(image_url)
    print(result)
