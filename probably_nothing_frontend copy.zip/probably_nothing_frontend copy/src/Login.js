import React, { useState } from 'react';
import axios from 'axios';
import { TextField, Button, makeStyles } from '@material-ui/core';

const useStyles = makeStyles({
  root: {
    height: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    // backgroundImage: `url(${process.env.PUBLIC_URL + '/gradient-network-connection-background/5039684.jpg'})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
    padding: '2rem',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: '0.7rem',
  },
  input: {
    color: '#fff',
  },
});

function Login() {
  const classes = useStyles();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();

    const response = await axios.post('http://localhost:8000/login', {
      username,
      password,
    });

    console.log(response.data);
  };

  return (
    <div style={{ 
      backgroundImage: `url(${process.env.PUBLIC_URL + '/gradient-network-connection-background/5039684.jpg'})`, 
      height: '100vh', 
      backgroundSize: 'cover' 
    }}>


        <div className={classes.root}>
        <form onSubmit={handleSubmit} className={classes.form}>
            <h1>GETSecured OracleSentry</h1>
            <TextField
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Username"
            InputProps={{ className: classes.input }}
            />
            <TextField
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            InputProps={{ className: classes.input }}
            />
            <Button type="submit" variant="contained" color="primary">
            Login
            </Button>
        </form>
        </div>


    </div>
    


  );
}

export default Login;
