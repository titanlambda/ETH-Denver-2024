import React, { useState } from 'react';
import axios from 'axios';
import { TextField, Button, Typography, makeStyles, CircularProgress } from '@material-ui/core';
import ContractFindingsTable from './ContractFindingsTable';

const useStyles = makeStyles((theme) => ({
  form: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: theme.spacing(2),
  },
  textField: {
    marginBottom: theme.spacing(2),
    width: '100%',
  },
  button: {
    width: '100%',
  },
}));

function PhosphorNFTRiskScoreForm() {
  const classes = useStyles();
  const [address, setAddress] = useState('');
  const [riskScore, setRiskScore] = useState(null);
  const [loading, setLoading] = useState(false);
  const [additionalData, setAdditionalData] = useState(null);
  const [findings, setFindings] = useState(null);

  const getRiskScore = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`http://0.0.0.0:8080/api/get_risk_score_get_phosphor_NFT_risk_score?nft_collection_id=${address}`);
      setRiskScore(response.data.risk_score);

      setAdditionalData(response.data); // store the entire response data
      // const new_findings = response.data.scan_result.contract_findings.filter(finding => ['High', 'Medium', 'Low', 'Informational'].includes(finding.Impact)).map((finding, index) => ({ ...finding, id: index + 1 }));
      // setFindings(new_findings);

    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const getRiskScoreColor = (score) => {
    if (score <= 30) {
      return 'green';
    } else if (score <= 60) {
      return 'orange';
    } else {
      return 'red';
    }
  };

  return (
    <div className={classes.form}>

      <img src="https://docs.phosphor.xyz/img/PhosphorDev-Logo_Black.png" alt="Probably Nothing" height="60" />

      <Typography variant="h5" gutterBottom>
        <pre> 
          Phosphor Based NFT Reputation Score: 
          <br/>
        </pre>
      </Typography>
      <TextField
        variant="outlined"
        className={classes.textField}
        value={address}
        onChange={e => setAddress(e.target.value)}
      />
      <Button
        variant="contained"
        color="primary"
        className={classes.button}
        onClick={getRiskScore}
        disabled={loading}
      >
        {loading ? <CircularProgress size={24} /> : 'Get Risk Score'}
      </Button>
      <br/>
      <br/>

      {additionalData && <img src={additionalData.image_url} alt="NFT Image" height="300"/>}
      
      <br/>
      {riskScore && <Typography variant="h6" style={{color:getRiskScoreColor(riskScore)}}>Risk Score: {riskScore}</Typography>}
      <br/>
      {additionalData && <Typography variant="h6"> NFT Name: {additionalData.name}</Typography>}
      {additionalData && <Typography variant="h6"> NFT Description: {additionalData.description}</Typography>}

      <div>
        {additionalData && additionalData.result_summary && Object.entries(additionalData.result_summary).filter(([key]) => ['Informational', 'Low', 'Medium', 'High'].includes(key)).map(([key, value]) => `${key}: ${value}`).join(', ')}
      </div>

      {findings && <div><ContractFindingsTable data={findings}/></div>}
      <br/>
      
    </div>
  );
}

export default PhosphorNFTRiskScoreForm;
