
import { Providers } from "./providers";


export const metadata = {
  title: "Probably Nothing",
  description: "Nothing",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Providers>
          <div className="content">{children}</div>
        </Providers>
      </body>
    </html>
  );
}
