import React, {useState, useEffect} from "react"
import * as fcl from "@blocto/fcl"
import { AppBar, Toolbar, Box, Typography, Tabs, Tab, Button, makeStyles } from '@material-ui/core';
import axios from 'axios';

import PhosphorNFTRiskScoreForm from './PhosphorNFTRiskScoreForm';

const timeOutInterval = 3000000;

const useStyles = makeStyles({
  root: {
    height: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundImage: `url(${process.env.PUBLIC_URL + '/gradient-network-connection-background/5039684.jpg'})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
    padding: '2rem',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: '0.7rem',
  },
  input: {
    color: '#fff',
  },
});

const SignInOutButton = ({ user: { loggedIn } }) => {
  const [data, setData] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(20);
  const [value, setValue] = useState(0);
  const [sessionTimeout, setSessionTimeout] = useState(null);
  const [hasSessionTimedOut, setHasSessionTimedOut] = useState(false);
  
  useEffect(() => {
    const fetchData = async () => {
      const result = await axios('http://0.0.0.0:8080/api/get_all_contract_stats_summary'); // Replace with your API link
      setData(result.data);
    };
    
    if(loggedIn && !data) {
      fetchData();
    }
  }, [loggedIn, data]);

  useEffect(() => {
    if (loggedIn) {
      setSessionTimeout(setTimeout(() => {
        fcl.unauthenticate();
        setHasSessionTimedOut(true);
      }, timeOutInterval)); // 10 seconds
    } else if (sessionTimeout) {
      clearTimeout(sessionTimeout);
    }
  }, [loggedIn, sessionTimeout]);

  const classes = useStyles();
  
  if (loggedIn && !data) {
    return 'Loading...';
  }

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleActivity = () => {
    if (sessionTimeout) {
      clearTimeout(sessionTimeout);
    }
    setSessionTimeout(setTimeout(() => {
      fcl.unauthenticate();
      setHasSessionTimedOut(true);
    }, timeOutInterval)); // 10 seconds
  };


  return (
    <div onMouseMove={handleActivity} onClick={handleActivity} onKeyDown={handleActivity}>
      <div style={{ 
        height: '100vh', 
        backgroundSize: 'cover' 
      }}>
        <AppBar position="static">
          <Toolbar>
            <img src="https://images.transistor.fm/images/logos/site/7965/medium_logo91_2x.png" alt="Probably Nothing" height="60" />
            <Box flexGrow={1} />
          </Toolbar>
        </AppBar>

        {(
          <>
            <Tabs value={value} onChange={handleChange}>
              <Tab label="Phosphor Based NFT Reputation Score" />
            </Tabs>
            {value === 0 && <PhosphorNFTRiskScoreForm />}
          </>

        )}
      </div>
    </div>
  )
}

const CurrentUser = () => {
  const [user, setUser] = useState({})

  useEffect(() =>
    fcl
      .currentUser()
      .subscribe(user => setUser({...user}))
  , [])

  return (
      <SignInOutButton user={user} />
  )
}

export default CurrentUser
