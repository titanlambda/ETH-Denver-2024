import React from 'react';
import { createTheme, ThemeProvider } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';


import Authenticate from './Authenticate'
import InsuranceContractListener from './InsuranceContractListener'


// Create a dark theme
const theme = createTheme({
  palette: {
    type: 'dark',
  },
});


function App() {


  return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Authenticate />
      </ThemeProvider>
  )

}

export default App;
